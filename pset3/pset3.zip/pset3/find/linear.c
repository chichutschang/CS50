    for(int i = 0; i < n; i++)
        {
         if (values[i] == value)
            {
            return true;
            }
        }
