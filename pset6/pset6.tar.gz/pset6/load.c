// feature test macro requirements
#define _GNU_SOURCE
#define _XOPEN_SOURCE 700
#define _XOPEN_SOURCE_EXTENDED

// limits on an HTTP request's size, based on Apache's
// http://httpd.apache.org/docs/2.2/mod/core.html
#define LimitRequestFields 50
#define LimitRequestFieldSize 4094
#define LimitRequestLine 8190

// number of bytes for buffers
#define BYTES 512

// header files
#include <arpa/inet.h>
#include <dirent.h>
#include <errno.h>
#include <limits.h>
#include <math.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

// types
typedef char BYTE;

// prototypes
bool connected(void);
void error(unsigned short code);
void freedir(struct dirent** namelist, int n);
void handler(int signal);
char* htmlspecialchars(const char* s);
char* indexes(const char* path);
void interpret(const char* path, const char* query);
void list(const char* path);
bool load(FILE* file, BYTE** content, size_t* length);
const char* lookup(const char* path);
bool parse(const char* line, char* path, char* query);
const char* reason(unsigned short code);
void redirect(const char* uri);
bool request(char** message, size_t* length);
void respond(int code, const char* headers, const char* body, size_t length);
void start(short port, const char* path);
void stop(void);
void transfer(const char* path, const char* type);
char* urldecode(const char* s);

bool load(FILE* file, BYTE** content, size_t* length)
//int main(void)
{
    //initialize file
    //FILE* file = NULL;
    
    //initialize content
    content = NULL;
    
    //initialize length
    length = 0;

    // check if file exists
    if (file == NULL)
    {
        error(500);
        return false;
    }
    
    //reads all available bytes from file
    BYTE buffer [BYTES];
    size_t bytes = fread(buffer, sizeof(BYTE), BYTES, file);
    
    //check for error
    if(ferror(file) != 0)
    {
        if (*content != NULL)
        {
            free(*content);
            *content = NULL;
            *length = 0;
        }
        return false;
    }

    //if bytes were read, stores those bytes contiguously in dynamically allocated memory on the heap
    if(bytes > 0)
    {
    //stores the address of the first of those bytes in *content
        *content = realloc(*content, *length + bytes);
        if (*content == NULL)
        {
            *length = 0;
            return false;
        }

        //stores the number of bytes in *length
        memcpy(*content + *length, buffer, bytes);
        *length += bytes;
    }
    
    //checks for end of file
    if(feof(file) != 0)
    {
        return false;
    }
  
    return *length;
}
