#include <stdio.h>
#include <string.h>
#include <strings.h>

/**
 * Returns MIME type for supported extensions, else NULL.
 */

const char* lookup(const char* path)
{
    //char str[] = "i.named.my.file.index.css";
    char *end;
    end = strrchr(path, '.');
    //printf("this file ends with %s\n", end+1);
    
    if (strcasecmp(end+1, "css") == 0)
    {
        return "text/css";
    }
    else if (strcasecmp(end+1, "html") == 0)
    {
        return "text/html";        
    }
    else if (strcasecmp(end+1, "ico") == 0)
    {
        return "image/gif";
    }
    else if (strcasecmp(end+1, "jpg") == 0)            
    {
        return "image/jpeg"; 
    }
    else if (strcasecmp(end+1, "js") == 0)
    {
        return "text/javascript"; 
    }
    else if (strcasecmp(end+1, "php") == 0)
    {
        return "text/x-php";
    }
    else if (strcasecmp(end+1, "png") == 0)
    {
        return "image/png";
    }
    return NULL;
}
