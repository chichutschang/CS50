// feature test macro requirements
#define _GNU_SOURCE
#define _XOPEN_SOURCE 700
#define _XOPEN_SOURCE_EXTENDED

// limits on an HTTP request's size, based on Apache's
// http://httpd.apache.org/docs/2.2/mod/core.html
#define LimitRequestFields 50
#define LimitRequestFieldSize 4094
#define LimitRequestLine 8190

// number of bytes for buffers
#define BYTES 512

// header files
#include <cs50.h>
#include <arpa/inet.h>
#include <dirent.h>
#include <errno.h>
#include <limits.h>
#include <math.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>


/**
 * Parses a request-line, storing its absolute-path at abs_path 
 * and its query string at query, both of which are assumed
 * to be at least of length LimitRequestLine + 1.
 */
//bool parse(const char* line, char* abs_path, char* query)
int main(void)
{
    // request line = method SP request-target SP HTTP-version CRLF
    // extract method & check if "GET" is in there
    // extract request-target & check if it begins with "/" and has "?"
    // extract HTTP-version & check if it's version "HTTP/1.1"
    // extract CRLF

    //initialize const char* line;
    const char* line = "GET /favicon.ico?=Alice HTTP/1.1\r\n";
    printf("line: %s\n",line);
    
    //set up arrays to hold abs_path & query 
    char abs_path[LimitRequestLine + 1];
    //printf("abs_path: %s\n", abs_path);
    char query[LimitRequestLine +1];
    //printf("query: %s\n", query);
    
    //ensures arguments aren't false
    //if ( line == NULL || abs_path == NULL || query == NULL)
    //{
    //    return false;
    //}
    
    //string to hold the entire name stored as an array
    const char* haystack = strdup(line);
    
    //get pointer to the first space
    const char* needle = strstr(haystack, " ");

    //checks if there's a space
    if (needle == NULL)
    {
        //error(400);
        return false;    
    }

    //extract method: initialize method as an array
    char method[needle - haystack + 1];  
    
    //copy the characters from beginning until reaches the first space
    strncpy (method, haystack, needle - haystack);
    
    //null terminate the string because strncpy doesn't do it automatically
    method[ needle - haystack] = '\0';
    
    //if method is not GET, respond with "405 Method Not Allowed" and return false
    if (strncmp (method,"GET", 3) == 0)
    {
        printf("method: %s\n", method);
        //error(405);
    }

    //extract request-target:
    haystack = needle + 1;
    
    //get pointer to the second space
    needle = strstr(haystack, " ");

    //checks if there's a space
    if (needle == NULL)
    {
        //error(400);
        return false;    
    }

    //initialize request-target as an array
    char request_target[needle - haystack + 1];  
    
    //copy the characters from beginning until reaches the first space
    strncpy (request_target, haystack, needle - haystack);
    
    //null terminate the string because strncpy doesn't do it automatically
    request_target[ needle - haystack] = '\0';
    
    //if request-target does not begin with /, respond to the browser with "501 Not Implemented" and return false
    if(strncmp (request_target,"/", 1) == 0)
    {
        printf("request-target: %s\n", request_target);
        //error(501);
    }

    //if request-target contains a " respond to the browser with "400 Bad Request" and return false    
    char apostrophe = '"';
    if (strstr(request_target, &apostrophe) != NULL)
    {
        printf("request-target: %s\n", request_target);
        //error(400);
    }
    
    //find end of absolute path in request-target
    haystack = request_target;
    needle = strchr(haystack, '?');
    
    if (needle == NULL)
    {
        needle = request_target + strlen(request_target);
    }
    
    //extract absolute path
    //copy the characters from beginning until reaches the first space
    strncpy (abs_path, haystack, needle - haystack);
    
    //null terminate the string because strncpy doesn't do it automatically
    abs_path[ needle - haystack] = '\0';
    
    if (strstr(abs_path, needle) == NULL)
    {
        strcpy (query, needle + 1);
        printf("query: %s\n", query);
    }

    else
    {
        strcpy (query, " ");    
        printf("query: %s\n", query);
    }

    //if request-target has "?", then copy request target into absolute path & everything after "?q" into query
    //char question = '?';
    //memset (abs_path, '\0', sizeof(abs_path));
    //memset (query, '\0', sizeof(query));
    //if (strstr(request_target, &question) == NULL)
    //{
    //    strncpy (abs_path, request_target, 12);
        //printf("%s\n", abs_path);
        
    //    if(strstr(abs_path, "?q") == NULL || strstr(abs_path, "?Q") == NULL)
    //    {
    //        strncpy (query, request_target, LimitRequestLine + 1);
    //        printf("%s\n", query);
    //    }
    //    else
    //    {
    //        strcpy (query, " ");    
    //        printf("%s\n", query);
    //    }            
    //}
    //if request-target does not have "?", then copy into absolute path
    //else
    //{
    //    strcpy (abs_path, request_target);
    //    printf("%s\n", abs_path);
    //}

    
    
    
    
    
    
    
    //extract version
    haystack = needle + 1;
    
    //get pointer to "\r\n" to find CRLF
    needle = strstr(haystack, "\r\n");

    //checks if there's a space
    if (needle == NULL)
    {
        //error(414);
        return false;    
    }

    //initialize version as an array
    char version[needle - haystack + 1];  

    //copy the characters from beginning until reaches the first space
    strncpy (version, haystack, needle - haystack);

    //null terminate the string because strncpy doesn't do it automatically
    version[needle - haystack] = '\0';
    printf("%s\n", version);
    
    if (strncmp (version, "HTTP/1.1", 8) == 0)
    {
        printf("%s\n", version);
        //error(505);
        //return false;
    }

        
    //printf("method: %s\n request_target: %s\n version: %s\n", method, request_target, version);

    //error(501);
    return false;
}

